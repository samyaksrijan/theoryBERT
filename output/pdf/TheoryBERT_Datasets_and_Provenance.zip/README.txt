TheoryBERT local datasets and provenance snapshot, 29 October 2026.

This archive includes overlapping generated corpus versions, the frozen challenge
sets, actual grammar training files, pinned public KB13 source bytes and their
MIT license, local generators/configurations and measured experiment provenance.
Versions overlap: do not sum their rows as independent data. The tiny original
challenge file and reference fixtures are not training benchmarks.

No BERT model weights are included. Pretrained artifact lineage is recorded in
artifacts/pretrained/bert-base-uncased/source.json. Raw BookCorpus and Wikipedia
were not downloaded or used for local training. The project requires the exact
local evaluated V3 encoder to reproduce the plan head. Generated files may not
be available on the public project repository. Paths here preserve project
relative locations. See CONTENTS_AND_SHA256.json for every packaged file.

External KB13 mirror:
https://github.com/nicholaslocascio/deep-regex/tree/096490db7f4b0394fbb46b914cb35a0aa1cba29c/datasets/KB13
License: data/generated/external/LICENSE.md (MIT, 2016 Nick Locascio).
Do not remove source notices when redistributing these external files.

Frozen v2 and retired v1 tests are already exposed. A later experiment needs a
new independent test version. This archive is reproducibility data, not evidence
that model interpretation is universally correct.
